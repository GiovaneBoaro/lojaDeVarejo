/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "index.html",
    "src/view/**/*.{html,php}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
