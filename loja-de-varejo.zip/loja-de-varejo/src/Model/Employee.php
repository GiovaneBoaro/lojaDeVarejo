<?php

namespace APP\Model;

class Employee
{
    private string $email;
    private string $password;
    private string $name;
    private int $register;
    private float $salary;
}
