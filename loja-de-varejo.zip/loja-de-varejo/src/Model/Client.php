<?php

namespace APP\Model;

class Client
{
    private string $cpf;
    private string $name;
    private string $email;
    private string $phone;
    private Address $address;
}
